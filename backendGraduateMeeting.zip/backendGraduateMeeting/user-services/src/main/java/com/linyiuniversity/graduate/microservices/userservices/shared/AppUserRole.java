package com.linyiuniversity.graduate.microservices.userservices.shared;

public enum AppUserRole {
    USER,
    STUDENT,
    TEACHER,
    LEADER,
    ADMIN,
    SUPER_ADMIN
}
